# TypeMate AI — Android keyboard prototype

This is the first starter project for TypeMate AI.

## Current prototype
- Android app shell
- Android Input Method Service (system keyboard)
- Basic QWERTY keys
- Space/voice/AI correction are not connected yet; those are the next milestones.

## Build
Requires JDK 17, Android SDK Platform 35, Android Build Tools, and Gradle 8.9.

From this project folder:
```bash
gradle assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Install and enable
1. Install the debug APK on an Android device.
2. Open TypeMate AI.
3. Tap "Enable TypeMate keyboard".
4. Enable TypeMate AI Keyboard in Android settings.
5. Tap "Choose TypeMate keyboard" and select it.
6. Test in a text field.

This is an early development prototype, not ready for public release.
Do not enter passwords or sensitive information while testing an unfinished keyboard.
