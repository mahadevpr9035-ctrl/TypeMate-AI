package com.typemate.ai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }

        val title = TextView(this).apply {
            text = "TypeMate AI"
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your voice. Your words. Better writing.\n\nFirst prototype: a working Android keyboard."
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        val enable = Button(this).apply {
            text = "1. Enable TypeMate keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. Choose TypeMate keyboard"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        val note = TextView(this).apply {
            text = "After enabling it, open WhatsApp or any text box and select TypeMate AI from the keyboard switcher."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(enable)
        layout.addView(choose)
        layout.addView(note)
        setContentView(layout)
    }
}
