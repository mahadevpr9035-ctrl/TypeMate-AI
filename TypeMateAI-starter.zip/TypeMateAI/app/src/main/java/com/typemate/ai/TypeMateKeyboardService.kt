package com.typemate.ai

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.inputmethod.EditorInfo

class TypeMateKeyboardService : InputMethodService() {
    private var keyboardRoot: LinearLayout? = null

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 7, 5, 7)
            setBackgroundColor(Color.rgb(235, 238, 244))
        }
        keyboardRoot = root

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        toolbar.addView(toolButton("TypeMate AI", 1.5f) { })
        toolbar.addView(toolButton("Fix", 1f) {
            // AI correction will be connected in the next milestone.
        })
        toolbar.addView(toolButton("🎙", 1f) {
            // Voice typing will be connected in the next milestone.
        })
        root.addView(toolbar)

        listOf("qwertyuiop", "asdfghjkl", "zxcvbnm").forEachIndexed { index, letters ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            if (index == 2) row.addView(keyButton("⇧", 1.2f) { })
            letters.forEach { char ->
                row.addView(keyButton(char.toString(), 1f) { commit(char.toString()) })
            }
            if (index == 2) row.addView(keyButton("⌫", 1.2f) { deleteOne() })
            root.addView(row)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottom.addView(keyButton("?123", 1.2f) { })
        bottom.addView(keyButton(",", 0.8f) { commit(",") })
        bottom.addView(keyButton("English", 2.8f) { })
        bottom.addView(keyButton("space", 2.0f) { commit(" ") })
        bottom.addView(keyButton(".", 0.8f) { commit(".") })
        bottom.addView(keyButton("↵", 1.2f) { enter() })
        root.addView(bottom)
        return root
    }

    private fun toolButton(label: String, weight: Float, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, dp(42), weight).apply {
                setMargins(dp(2), dp(2), dp(2), dp(5))
            }
        }
    }

    private fun keyButton(label: String, weight: Float, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.rgb(30, 35, 45))
            setBackgroundColor(Color.WHITE)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, dp(48), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
        }
    }

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
    }

    private fun deleteOne() {
        currentInputConnection?.deleteSurroundingText(1, 0)
    }

    private fun enter() {
        val info: EditorInfo = currentInputEditorInfo ?: return
        val action = info.imeOptions and EditorInfo.IME_MASK_ACTION
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else {
            commit("\n")
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
